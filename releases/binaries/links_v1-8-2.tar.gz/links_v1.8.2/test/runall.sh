./runme_EcoliK12single.sh
./runme_StyphiH58iterative.sh
./runme_EcoliK12iterative.sh
./runme_EcoliK12iterativeRAW.sh
./runme_EcoliK12iterativeA2D.sh
./runme_ScerevisiaeS288citerative.sh
./runme_ScerevisiaeW303iterative.sh
