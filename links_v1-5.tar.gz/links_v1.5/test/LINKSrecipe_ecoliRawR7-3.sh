### RAN: ./LINKSrecipe_ecoliRawR7-3.txt 15 3 5 0.3 at unix prompt (table 1H in manuscript)
### longread = /projects/btl/datasets/ecoli/oxfordNanopore_SEP2014/R7.3/fast5/allreads.fa (Quick et al R7.3 all reads from fast5)
../LINKS -f abyssEcoliScaffolds.fa -s longread.fa -b links1 -d 500 -t $2 -k $1 -l $3 -a $4
../LINKS -f links1.scaffolds.fa -s longread.fa -b links2 -d 750 -t $2 -k $1 -l $3 -a $4
../LINKS -f links2.scaffolds.fa -s longread.fa -b links3 -d 1000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links3.scaffolds.fa -s longread.fa -b links4 -d 1250 -t $2 -k $1 -l $3 -a $4
../LINKS -f links4.scaffolds.fa -s longread.fa -b links5 -d 1500 -t $2 -k $1 -l $3 -a $4
../LINKS -f links5.scaffolds.fa -s longread.fa -b links6 -d 1750 -t $2 -k $1 -l $3 -a $4
../LINKS -f links6.scaffolds.fa -s longread.fa -b links7 -d 3000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links7.scaffolds.fa -s longread.fa -b links8 -d 3250 -t $2 -k $1 -l $3 -a $4
../LINKS -f links8.scaffolds.fa -s longread.fa -b links9 -d 3500 -t $2 -k $1 -l $3 -a $4
../LINKS -f links9.scaffolds.fa -s longread.fa -b links10 -d 3750 -t $2 -k $1 -l $3 -a $4
../LINKS -f links10.scaffolds.fa -s longread.fa -b links11 -d 4000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links11.scaffolds.fa -s longread.fa -b links12 -d 4500 -t $2 -k $1 -l $3 -a $4
../LINKS -f links12.scaffolds.fa -s longread.fa -b links13 -d 4750 -t $2 -k $1 -l $3 -a $4
../LINKS -f links13.scaffolds.fa -s longread.fa -b links14 -d 5000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links14.scaffolds.fa -s longread.fa -b links15 -d 5250 -t $2 -k $1 -l $3 -a $4
../LINKS -f links15.scaffolds.fa -s longread.fa -b links16 -d 5500 -t $2 -k $1 -l $3 -a $4
../LINKS -f links16.scaffolds.fa -s longread.fa -b links17 -d 5750 -t $2 -k $1 -l $3 -a $4
../LINKS -f links17.scaffolds.fa -s longread.fa -b links18 -d 6000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links18.scaffolds.fa -s longread.fa -b links19 -d 6250 -t $2 -k $1 -l $3 -a $4
../LINKS -f links19.scaffolds.fa -s longread.fa -b links20 -d 6500 -t $2 -k $1 -l $3 -a $4
../LINKS -f links20.scaffolds.fa -s longread.fa -b links21 -d 7000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links21.scaffolds.fa -s longread.fa -b links22 -d 8000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links22.scaffolds.fa -s longread.fa -b links23 -d 9000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links23.scaffolds.fa -s longread.fa -b links24 -d 10000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links24.scaffolds.fa -s longread.fa -b links25 -d 11000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links25.scaffolds.fa -s longread.fa -b links26 -d 12000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links26.scaffolds.fa -s longread.fa -b links27 -d 13000 -t $2 -k $1 -l $3 -a $4
echo Optimum Assembly Reached!
../LINKS -f links27.scaffolds.fa -s longread.fa -b links28 -d 14000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links28.scaffolds.fa -s longread.fa -b links29 -d 15000 -t $2 -k $1 -l $3 -a $4
../LINKS -f links29.scaffolds.fa -s longread.fa -b links30 -d 16000 -t $2 -k $1 -l $3 -a $4
